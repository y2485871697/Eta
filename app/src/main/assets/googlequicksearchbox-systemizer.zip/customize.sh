REPLACE="/system/priv-app/GoogleQuickSearchBox"

PACKAGE=com.google.android.googlequicksearchbox
APP_DIR=$MODPATH/system/priv-app/GoogleQuickSearchBox

mkdir -p "$APP_DIR"
find "$APP_DIR" -maxdepth 1 -type f -name '*.apk' -delete 2>/dev/null

pm path "$PACKAGE" 2>/dev/null |
  sed -n 's/^package://p' |
  while IFS= read -r apk; do
    [ -f "$apk" ] || continue
    cp -f "$apk" "$APP_DIR/${apk##*/}"
done

set_perm_recursive $MODPATH 0 0 0755 0644
