/* -*- c-set-style: "K&R"; c-basic-offset: 8 -*-
 *
 * This file is part of PRoot.
 *
 * Copyright (C) 2015 STMicroelectronics
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 */

#ifndef TRACEE_H
#define TRACEE_H

#include <sys/types.h> /* pid_t, size_t, */
#include <sys/user.h>  /* struct user*, */
#include <stdbool.h>   /* bool,  */
#include <sys/queue.h> /* LIST_*, */
#include <sys/ptrace.h>/* enum __ptrace_request */
#include <talloc.h>    /* talloc_*, */
#include <stdint.h>    /* *int*_t, */

#include "arch.h" /* word_t, user_regs_struct, HAS_POKEDATA_WORKAROUND */
#include "compat.h"

typedef enum {
	CURRENT  = 0,
	ORIGINAL = 1,
	MODIFIED = 2,
	ORIGINAL_SECCOMP_REWRITE = 3,
	NB_REG_VERSION
} RegVersion;

struct bindings;
struct load_info;
struct extensions;
struct chained_syscalls;

/* Information related to a file-system name-space.  */
typedef struct {
	struct {
		/* List of bindings as specified by the user but not canonicalized yet.  */
		struct bindings *pending;

		/* List of bindings canonicalized and sorted in the "guest" order.  */
		struct bindings *guest;

		/* List of bindings canonicalized and sorted in the "host" order.  */
		struct bindings *host;
	} bindings;

	/* Current working directory, à la /proc/self/pwd.  */
	char *cwd;
} FileSystemNameSpace;

/* Virtual heap, emulated with a regular memory mapping.  */
typedef struct {
	word_t base;
	size_t size;
	bool disabled;
} Heap;

/* Information related to a tracee process. */
typedef struct tracee {
	/**********************************************************************
	 * Private resources                                                  *
	 **********************************************************************/

	/* Link for the list of all tracees.  */
	LIST_ENTRY(tracee) link;

	/* Process identifier. */
	pid_t pid;

	/* Unique tracee identifier. */
	uint64_t vpid;

	/* Is it currently running or not?  */
	bool running;

	/* Is this tracee ready to be freed?  TODO: move to a list
	 * dedicated to terminated tracees instead.  */
	bool terminated;

	/* Whether termination of this tracee implies an immediate kill
	 * of all tracees. */
	bool killall_on_exit;

	/* Parent of this tracee, NULL if none.  */
	struct tracee *parent;

	/* Is it a "clone", i.e has the same parent as its creator.  */
	bool clone;

	/* Set when the current clone(2)/clone3(2) had CLONE_NEW* flags
	 * stripped (see translate_syscall_enter); the new child should
	 * get its own copy of the bindings so emulated mount(2) calls
	 * stay scoped to the would-be namespace.  Reset once consumed.  */
	bool clone_stripped_newns;

	/* Same for CLONE_NEWNET, propagated to the new child as
	 * "fake_netns" below.  Reset once consumed.  */
	bool clone_stripped_newnet;

	/* Set once this tracee asked for a network namespace of its own
	 * -- clone(2) or unshare(2) with CLONE_NEWNET -- and PRoot
	 * pretended it got one.  Inherited by children, which would
	 * share that namespace.  */
	bool fake_netns;

	/* Emulation of AF_NETLINK / NETLINK_ROUTE sockets for
	 * sandbox helpers like bubblewrap that try to bring up the
	 * loopback interface inside their would-be net namespace.
	 * fake_netlink_fds holds one entry per socket we silently
	 * redirected from AF_NETLINK to AF_UNIX/SOCK_DGRAM; see
	 * enter.c / exit.c for the intercepts.
	 *
	 * "reply" is what PRoot synthesised at send time for that socket's
	 * latest request, waiting for the matching recvmsg / recvfrom.  It
	 * belongs to the socket rather than to the tracee because sockets
	 * have receive queues of their own: iproute2 walks a route dump on
	 * one of them while a second answers the interface lookups it makes
	 * along the way.  The buffer is allocated on demand and handed back
	 * one datagram at a time ("reply_off" is how far the tracee has
	 * read), since that is how the kernel delivers a dump.  */
#define MAX_FAKE_NETLINK_FDS 8
#define MAX_FAKE_NETLINK_REPLY 8192
	struct fake_netlink_socket {
		int fd;
		uint8_t *reply;
		size_t reply_len;
		size_t reply_off;
	} fake_netlink_fds[MAX_FAKE_NETLINK_FDS];
	int fake_netlink_fds_count;
	bool pending_fake_netlink_socket;

	/* Fds of the *real* NETLINK_ROUTE sockets a tracee got when the
	 * host didn't need the substitution above.  Such a socket lives
	 * in the host's network namespace, where a tracee has no
	 * CAP_NET_ADMIN, so the requests a fake_netns tracee sends to
	 * configure "its" namespace come back as NLMSG_ERROR(-EPERM);
	 * netlink_ack_* remembers which reply to turn into a plain ack
	 * (see handle_netlink_reply_exit).  */
#define MAX_NETLINK_ROUTE_FDS 8
	int netlink_route_fds[MAX_NETLINK_ROUTE_FDS];
	int netlink_route_fds_count;
	bool pending_real_netlink_socket;
	bool netlink_ack_pending;
	int netlink_ack_fd;
	uint32_t netlink_ack_seq;

	/* Support for ptrace emulation (tracer side).  */
	struct {
		size_t nb_ptracees;
		LIST_HEAD(zombies, tracee) zombies;

		pid_t wait_pid;
		word_t wait_options;

		enum {
			DOESNT_WAIT = 0,
			WAITS_IN_KERNEL,
			WAITS_IN_PROOT
		} waits_in;
	} as_ptracer;

	/* Support for ptrace emulation (tracee side).  */
	struct {
		struct tracee *ptracer;

		struct {
			#define STRUCT_EVENT struct { int value; bool pending; }

			STRUCT_EVENT proot;
			STRUCT_EVENT ptracer;
		} event4;

		bool tracing_started;
		bool ignore_loader_syscalls;
		bool ignore_syscalls;
		word_t options;
		bool is_zombie;
	} as_ptracee;

	/* Current status:
	 *        0: enter syscall
	 *        1: exit syscall no error
	 *   -errno: exit syscall with error.  */
	int status;

#define IS_IN_SYSENTER(tracee) ((tracee)->status == 0)
#define IS_IN_SYSEXIT(tracee) (!IS_IN_SYSENTER(tracee))
#define IS_IN_SYSEXIT2(tracee, sysnum) (IS_IN_SYSEXIT(tracee) \
				     && get_sysnum((tracee), ORIGINAL) == sysnum)

	/* How this tracee is restarted.  */
#ifdef __GLIBC__
	enum __ptrace_request
#else
	int
#endif
		restart_how, last_restart_how;

	/* Value of the tracee's general purpose registers.  */
	struct user_regs_struct _regs[NB_REG_VERSION];
	bool _regs_were_changed;
	bool restore_original_regs;
	bool restore_original_regs_after_seccomp_event;

	/* State for the special handling of SIGSTOP.  */
	enum {
		SIGSTOP_IGNORED = 0,  /* Ignore SIGSTOP (once the parent is known).  */
		SIGSTOP_ALLOWED,      /* Allow SIGSTOP (once the parent is known).   */
		SIGSTOP_PENDING,      /* Block SIGSTOP until the parent is unknown.  */
	} sigstop;

	/* True if next SIGSYS caused by seccomp should be silently dropped
	 * without affecting state of any registers.  */
	bool skip_next_seccomp_signal;

	/* True when the sysenter stage voided the current syscall into a
	 * number the host kernel cancels instead of executing.  Such a
	 * syscall reports no sysenter ptrace stop, only a sysexit one, so
	 * the event loop must not expect the former.  Set at the end of
	 * the sysenter stage by translate_syscall().  */
	bool voided_syscall_cancelled;

	/* True when an outer-seccomp SIGSYS was preceded by a synthesized
	 * sysexit (translate_syscall) that may have poked SYSARG_RESULT.  On
	 * ARM/ARM64 SYSARG_RESULT aliases SYSARG_1, so the blocked syscall's
	 * first argument must be restored from the entry snapshot before it is
	 * emulated or restarted.  See handle_seccomp_event().  */
	bool restore_sysarg1_after_sigsys;

	/* Context used to collect all the temporary dynamic memory
	 * allocations.  */
	TALLOC_CTX *ctx;

	/* Context used to collect all dynamic memory allocations that
	 * should be released once this tracee is freed.  */
	TALLOC_CTX *life_context;

	/* Note: I could rename "ctx" in "event_span" and
	 * "life_context" in "life_span".  */

	/* Specify the type of the final component during the
	 * initialization of a binding.  This variable is first
	 * defined in bind_path() then used in build_glue().  */
	mode_t glue_type;

	/* During a sub-reconfiguration, the new setup is relatively
	 * to @tracee's file-system name-space.  Also, @paths holds
	 * its $PATH environment variable in order to emulate the
	 * execvp(3) behavior.  */
	struct {
		struct tracee *tracee;
		const char *paths;
	} reconf;

	/* Unrequested syscalls inserted by PRoot after an actual
	 * syscall.  */
	struct {
		struct chained_syscalls *syscalls;
		bool force_final_result;
		word_t final_result;
		enum {
			SYSNUM_WORKAROUND_INACTIVE,
			SYSNUM_WORKAROUND_PROCESS_FAULTY_CALL,
			SYSNUM_WORKAROUND_PROCESS_REPLACED_CALL
		} sysnum_workaround_state;
		int suppressed_signal;
	} chain;

	/* Load info generated during execve sysenter and used during
	 * execve sysexit.  */
	struct load_info *load_info;

	/* Address of argv[0] string in the tracee's initial stack, captured
	 * at execve sysexit. Used to fix AT_EXECFN in prctl(PR_GET_AUXV)
	 * responses: the kernel's saved auxv has AT_EXECFN pointing to the
	 * loader temp file, but we want it to point to the actual program name. */
	word_t execfn_addr;

	/* fd the tracee used to open /proc/self/auxv, tracked so that read()
	 * calls on it can have AT_EXECFN patched (fallback for kernels < 6.4
	 * that don't support prctl(PR_GET_AUXV)). -1 when not active. */
	int auxv_fd;

#ifdef HAS_POKEDATA_WORKAROUND
	word_t pokedata_workaround_stub_addr;
	bool pokedata_workaround_cancelled_syscall;
	bool pokedata_workaround_relaunched_syscall;
#endif

#ifdef ARCH_ARM64
	bool is_aarch32;
#endif


	/**********************************************************************
	 * Private but inherited resources                                    *
	 **********************************************************************/

	/* Verbose level.  */
	int verbose;

	/* State of the seccomp acceleration for this tracee.  */
	enum { DISABLED = 0, DISABLING, ENABLED } seccomp;

	/* Ensure the sysexit stage is always hit under seccomp.  */
	bool sysexit_pending;

	/* If true, syscall entry was handled by seccomp and next SIGTRAP | 0x80
	 * has to be ignored as it's same syscall entry */
	bool seccomp_already_handled_enter;

	/* Whether the tracee itself requested the "no new privileges" flag
	 * via prctl(PR_SET_NO_NEW_PRIVS).  PRoot always sets the real kernel
	 * flag in the child before execve (it is a precondition for installing
	 * its seccomp filter), so prctl(PR_GET_NO_NEW_PRIVS) would otherwise
	 * report 1 even though the guest never asked for it.  This field lets
	 * PRoot report the guest's own intent instead, which is required by
	 * tools like sudo-rs that refuse to run when the flag appears set. */
	bool no_new_privs;

	/* Set once the tracee has gone through its initial execve, i.e. once
	 * the guest program is actually running.  Used to ignore the
	 * PR_SET_NO_NEW_PRIVS that PRoot performs itself in the launch child
	 * (before that execve) when tracking @no_new_privs. */
	bool seen_execve;

	/**********************************************************************
	 * Shared or private resources, depending on the CLONE_FS/VM flags.   *
	 **********************************************************************/

	/* Information related to a file-system name-space.  */
	FileSystemNameSpace *fs;

	/* Virtual heap, emulated with a regular memory mapping.  */
	Heap *heap;


	/**********************************************************************
	 * Shared resources until the tracee makes a call to execve().        *
	 **********************************************************************/

	/* Path to the executable, à la /proc/self/exe.  */
	char *exe;
	char *new_exe;
	char *host_exe;


	/**********************************************************************
	 * Shared or private resources, depending on the (re-)configuration   *
	 **********************************************************************/

	/* Runner command-line.  */
	char **qemu;
	bool skip_proot_loader;

	/* Path to glue between the guest rootfs and the host rootfs.  */
	const char *glue;

	/* List of extensions enabled for this tracee.  */
	struct extensions *extensions;


	/**********************************************************************
	 * Shared but read-only resources                                     *
	 **********************************************************************/

	/* For the mixed-mode, the guest LD_LIBRARY_PATH is saved
	 * during the "guest -> host" transition, in order to be
	 * restored during the "host -> guest" transition (only if the
	 * host LD_LIBRARY_PATH hasn't changed).  */
	const char *host_ldso_paths;
	const char *guest_ldso_paths;

	/* For diagnostic purpose.  */
	const char *tool_name;

} Tracee;

#define HOST_ROOTFS "/host-rootfs"

#define TRACEE(a) talloc_get_type_abort(talloc_parent(talloc_parent(a)), Tracee)

extern Tracee *get_tracee(const Tracee *tracee, pid_t pid, bool create);
extern Tracee *get_stopped_ptracee(const Tracee *ptracer, pid_t pid,
				bool only_with_pevent, word_t wait_options);
extern bool has_ptracees(const Tracee *ptracer, pid_t pid, word_t wait_options);
extern int new_child(Tracee *parent, word_t clone_flags);
extern Tracee *new_dummy_tracee(TALLOC_CTX *context);
extern void terminate_tracee(Tracee *tracee);
extern void free_terminated_tracees();
extern int swap_config(Tracee *tracee1, Tracee *tracee2);
extern void kill_all_tracees();

typedef LIST_HEAD(tracees, tracee) Tracees;
extern Tracees *get_tracees_list_head();

#endif /* TRACEE_H */
